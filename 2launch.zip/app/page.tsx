'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Bot, FileCode, ImageIcon, Link2, Loader2, Send, Terminal, Rocket } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

const QUICK_STARTS = [
  { title: "Criar um dashboard Next.js", icon: Terminal, slug: "nextjs-dashboard" },
  { title: "Construir um site de e-commerce", icon: FileCode, slug: "ecommerce-site" },
  { title: "Projetar uma landing page", icon: ImageIcon, slug: "landing-page" },
  { title: "Implantar um app full-stack", icon: Rocket, slug: "full-stack-app" },
]

const FRAMEWORKS = [
  { name: "Next.js", icon: "/placeholder.svg?height=32&width=32", slug: "nextjs" },
  { name: "React", icon: "/placeholder.svg?height=32&width=32", slug: "react" },
  { name: "Vue", icon: "/placeholder.svg?height=32&width=32", slug: "vue" },
  { name: "Svelte", icon: "/placeholder.svg?height=32&width=32", slug: "svelte" },
  { name: "Angular", icon: "/placeholder.svg?height=32&width=32", slug: "angular" },
  { name: "Node.js", icon: "/placeholder.svg?height=32&width=32", slug: "nodejs" },
  { name: "Python", icon: "/placeholder.svg?height=32&width=32", slug: "python" },
  { name: "Java", icon: "/placeholder.svg?height=32&width=32", slug: "java" },
]

export default function HomePage() {
  const [prompt, setPrompt] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim() || loading) return
    
    setLoading(true)
    try {
      // Simulate AI response delay
      await new Promise(resolve => setTimeout(resolve, 1500))
      // Here you would add logic to process the prompt with AI
      console.log("Processing prompt:", prompt)
    } catch (error) {
      console.error("Error processing prompt:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <main className="flex-1 overflow-auto">
        <div className="mx-auto max-w-4xl px-4 py-8 sm:py-12 md:py-16">
          <div className="text-center space-y-4 mb-8">
            <h1 className="text-3xl font-bold sm:text-4xl md:text-5xl lg:text-6xl bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
              O que você quer lançar?
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-gray-400">
              Transforme suas ideias em realidade com desenvolvimento potencializado por IA
            </p>
          </div>

          <Card className="border-white/10 bg-gray-900/50 p-4 mb-8">
            <form onSubmit={handleSubmit} className="space-y-4">
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Descreva o que você quer construir..."
                className="min-h-[120px] resize-none border-white/10 bg-transparent text-white placeholder:text-gray-400 focus-visible:ring-blue-500"
              />
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex gap-2">
                  <Button 
                    type="button" 
                    size="icon" 
                    variant="ghost" 
                    className="text-gray-400 hover:text-white"
                    aria-label="Anexar código"
                  >
                    <FileCode className="h-4 w-4" />
                  </Button>
                  <Button 
                    type="button" 
                    size="icon" 
                    variant="ghost"
                    className="text-gray-400 hover:text-white"
                    aria-label="Anexar imagem"
                  >
                    <ImageIcon className="h-4 w-4" />
                  </Button>
                  <Button 
                    type="button" 
                    size="icon" 
                    variant="ghost"
                    className="text-gray-400 hover:text-white"
                    aria-label="Adicionar link"
                  >
                    <Link2 className="h-4 w-4" />
                  </Button>
                </div>
                <Button 
                  type="submit" 
                  disabled={!prompt.trim() || loading}
                  className={cn(
                    "bg-blue-600 hover:bg-blue-700 w-full sm:w-auto",
                    loading && "animate-pulse"
                  )}
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Processando...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Lançar
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Card>

          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {QUICK_STARTS.map((item) => (
                <Link key={item.slug} href={`/quick-start/${item.slug}`} passHref>
                  <Button
                    variant="ghost"
                    className="h-auto w-full justify-start gap-4 border border-white/10 p-4 text-left text-white/90 hover:bg-white/5"
                  >
                    <item.icon className="h-5 w-5 text-blue-500 flex-shrink-0" />
                    <span className="text-sm sm:text-base">{item.title}</span>
                  </Button>
                </Link>
              ))}
            </div>
            
            <Separator className="bg-white/10" />
            
            <div className="space-y-4">
              <p className="text-center text-sm text-gray-400">
                ou comece com seu framework favorito
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                {FRAMEWORKS.map((framework) => (
                  <Link key={framework.slug} href={`/framework/${framework.slug}`} passHref>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-12 w-12 rounded-xl border border-white/10 p-2 hover:bg-white/5"
                      aria-label={`Começar com ${framework.name}`}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={framework.icon}
                        alt={framework.name}
                        className="h-full w-full object-contain"
                      />
                    </Button>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

