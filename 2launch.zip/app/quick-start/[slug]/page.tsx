import { notFound } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import Link from 'next/link'
import { ArrowLeft, Terminal, FileCode, ImageIcon, Rocket } from 'lucide-react'

const QUICK_STARTS = [
  { 
    title: "Create a Next.js dashboard", 
    icon: Terminal, 
    slug: "nextjs-dashboard",
    description: "Build a responsive admin dashboard using Next.js and Tailwind CSS.",
    steps: [
      "Set up a new Next.js project",
      "Install and configure Tailwind CSS",
      "Create reusable dashboard components",
      "Implement responsive layouts",
      "Add mock data and charts"
    ]
  },
  { 
    title: "Build an e-commerce site", 
    icon: FileCode, 
    slug: "ecommerce-site",
    description: "Create a fully functional e-commerce site with product listings and a shopping cart.",
    steps: [
      "Initialize a new React project",
      "Set up routing and navigation",
      "Create product listing and detail pages",
      "Implement a shopping cart with context API",
      "Add checkout process and payment integration"
    ]
  },
  { 
    title: "Design a landing page", 
    icon: ImageIcon, 
    slug: "landing-page",
    description: "Design and develop a high-converting landing page for your product or service.",
    steps: [
      "Plan the landing page structure and content",
      "Create a responsive layout with CSS Grid and Flexbox",
      "Design eye-catching hero section and call-to-actions",
      "Implement smooth scrolling and animations",
      "Optimize for performance and SEO"
    ]
  },
  { 
    title: "Deploy a full-stack app", 
    icon: Rocket, 
    slug: "full-stack-app",
    description: "Build and deploy a full-stack application with a Node.js backend and React frontend.",
    steps: [
      "Set up a Node.js backend with Express",
      "Create a React frontend with create-react-app",
      "Implement API routes and database integration",
      "Connect frontend and backend",
      "Deploy to a cloud platform like Vercel or Heroku"
    ]
  },
]

export default function QuickStartPage({ params }: { params: { slug: string } }) {
  const quickStart = QUICK_STARTS.find(qs => qs.slug === params.slug)

  if (!quickStart) {
    notFound()
  }

  const Icon = quickStart.icon

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-blue-500 hover:text-blue-600 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Voltar para a página inicial
      </Link>
      <Card className="bg-gray-900/50 border-white/10">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className="bg-blue-500 p-2 rounded-full">
              <Icon className="h-6 w-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-white">{quickStart.title}</CardTitle>
              <CardDescription className="text-gray-400">{quickStart.description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <h3 className="text-lg font-semibold text-white mb-4">Passos para começar:</h3>
          <ol className="list-decimal list-inside space-y-2 text-gray-300">
            {quickStart.steps.map((step, index) => (
              <li key={index}>{step}</li>
            ))}
          </ol>
          <Button className="mt-6 bg-blue-600 hover:bg-blue-700">
            Iniciar Projeto
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

