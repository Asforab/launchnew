import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 text-center">
      <h1 className="text-4xl font-bold mb-4">404 - Página não encontrada</h1>
      <p className="text-xl mb-8">Desculpe, a página que você está procurando não existe.</p>
      <Link href="/">
        <Button className="bg-blue-600 hover:bg-blue-700">
          Voltar para a página inicial
        </Button>
      </Link>
    </div>
  )
}

