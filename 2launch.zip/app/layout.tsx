import '@/styles/globals.css'
import { Inter } from 'next/font/google'
import { Metadata } from 'next'
import { Rocket } from 'lucide-react'
import { Button } from "@/components/ui/button"
import Link from 'next/link'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: '2Launch - Plataforma de Desenvolvimento Potencializada por IA',
  description: 'Transforme suas ideias em realidade com desenvolvimento potencializado por IA',
  icons: {
    icon: '/favicon.ico',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" className="dark">
      <body className={`${inter.className} flex flex-col min-h-screen bg-black text-white`}>
        <header className="sticky top-0 z-50 flex items-center justify-between border-b border-white/10 bg-black/95 px-4 py-3 backdrop-blur supports-[backdrop-filter]:bg-black/60">
          <Link href="/" className="flex items-center gap-2">
            <Rocket className="h-6 w-6 text-blue-500" />
            <span className="font-bold text-xl">2Launch</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="ghost" size="sm" className="text-white/90 hover:text-white">
                Entrar
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                Cadastrar
              </Button>
            </Link>
          </div>
        </header>

        <main className="flex-grow">
          {children}
        </main>

        <footer className="border-t border-white/10 bg-black px-4 py-6 text-sm text-gray-400">
          <div className="mx-auto flex max-w-4xl flex-col items-center justify-between gap-4 sm:flex-row">
            <div className="flex items-center gap-2">
              <Rocket className="h-4 w-4" />
              <span>© 2024 2Launch. Todos os direitos reservados.</span>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="link" size="sm" className="text-gray-400 hover:text-white">
                Documentação
              </Button>
              <Button variant="link" size="sm" className="text-gray-400 hover:text-white">
                Termos
              </Button>
              <Button variant="link" size="sm" className="text-gray-400 hover:text-white">
                Privacidade
              </Button>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}



import './globals.css'