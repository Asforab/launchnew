import { notFound } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

const FRAMEWORKS = [
  { 
    name: "Next.js", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "nextjs",
    description: "O framework React para produção",
    features: [
      "Renderização híbrida estática e de servidor",
      "Suporte TypeScript",
      "Roteamento inteligente",
      "Divisão de código automática",
      "Otimização de imagem"
    ]
  },
  { 
    name: "React", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "react",
    description: "Uma biblioteca JavaScript para construir interfaces de usuário",
    features: [
      "Componentes reutilizáveis",
      "Virtual DOM para melhor performance",
      "Fluxo de dados unidirecional",
      "Ecossistema rico",
      "Suporte para aplicações de página única e móveis"
    ]
  },
  { 
    name: "Vue", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "vue",
    description: "O framework JavaScript progressivo",
    features: [
      "Curva de aprendizado suave",
      "Reatividade poderosa",
      "Componentes de arquivo único",
      "Ferramentas oficiais robustas",
      "Desempenho otimizado"
    ]
  },
  { 
    name: "Svelte", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "svelte",
    description: "Construa aplicações web cibernéticamente aprimoradas",
    features: [
      "Sem Virtual DOM",
      "Verdadeira reatividade",
      "Menos código, mais funcionalidade",
      "Compilação em tempo de construção",
      "Transições integradas"
    ]
  },
  { 
    name: "Angular", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "angular",
    description: "A plataforma moderna para construir aplicações web",
    features: [
      "Injeção de dependência robusta",
      "Templates declarativos",
      "Ferramentas de linha de comando poderosas",
      "RxJS para programação reativa",
      "Testabilidade integrada"
    ]
  },
  { 
    name: "Node.js", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "nodejs",
    description: "JavaScript runtime construído no motor V8 do Chrome",
    features: [
      "Execução de JavaScript no servidor",
      "Arquitetura orientada a eventos",
      "Ecossistema npm vasto",
      "Excelente para aplicações em tempo real",
      "Suporte nativo para protocolos web"
    ]
  },
  { 
    name: "Python", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "python",
    description: "Linguagem de programação de alto nível, interpretada e de propósito geral",
    features: [
      "Sintaxe clara e legível",
      "Extensa biblioteca padrão",
      "Suporte para múltiplos paradigmas de programação",
      "Grande comunidade e ecossistema",
      "Excelente para ciência de dados e aprendizado de máquina"
    ]
  },
  { 
    name: "Java", 
    icon: "/placeholder.svg?height=64&width=64", 
    slug: "java",
    description: "Linguagem de programação de propósito geral, baseada em classes e orientada a objetos",
    features: [
      "Portabilidade 'write once, run anywhere'",
      "Forte tipagem e segurança de memória",
      "Ampla adoção em empresas",
      "Ecossistema maduro e robusto",
      "Excelente para aplicações empresariais e Android"
    ]
  },
]

export default function FrameworkPage({ params }: { params: { slug: string } }) {
  const framework = FRAMEWORKS.find(fw => fw.slug === params.slug)

  if (!framework) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-blue-500 hover:text-blue-600 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Voltar para a página inicial
      </Link>
      <Card className="bg-gray-900/50 border-white/10">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className="bg-white p-2 rounded-full">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={framework.icon} alt={framework.name} className="h-12 w-12" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-white">{framework.name}</CardTitle>
              <CardDescription className="text-gray-400">{framework.description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <h3 className="text-lg font-semibold text-white mb-4">Principais características:</h3>
          <ul className="list-disc list-inside space-y-2 text-gray-300">
            {framework.features.map((feature, index) => (
              <li key={index}>{feature}</li>
            ))}
          </ul>
          <Button className="mt-6 bg-blue-600 hover:bg-blue-700">
            Começar com {framework.name}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

